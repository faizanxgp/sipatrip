<?php $__env->startSection('title'); ?>
	Hotel
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


	<section class="login">
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-md-push-3">
					<div class="complete-box">
						<div class="panel1">
							<div class="log-img">
								<img src="<?php echo e(URL::to('src/images/login.png')); ?>">
							</div>
							<div class="l-panel">
								<h4>LOGIN PANEL</h4>
							</div>
						</div>

						<form class="signin" method="post" action="<?php echo e(route('hotel.login.submit')); ?>">
							<div class="log-box">

								<div class="log">
									<input class="email1" type="email" placeholder="Email" name="email" required>
									<?php if($errors->has('email')): ?>
										<span class="help-block">
											<strong><?php echo e($errors->first('email')); ?></strong>
										</span>
									<?php endif; ?>

									<input class="email1" type="password" placeholder="Password" name="password" required>
								</div>
								<div class="remember-pass">
									<div class="remember">
										<input class="check" type="checkbox" checked="checked"> Remember me
									</div>
									<div class="fg-pass">
										<div>
											<span class="psw">Forgot password?</span>

											<a href="<?php echo e(route('password.request')); ?>"><strong>Click Here</strong></a>
										</div>
									</div>
								</div>
								<button class="btn btn-danger butn1" type="submit">LOG IN</button>
								<?php echo e(csrf_field()); ?>

								<p class="power">Powered by <strong>KIBAK-IT-TRAVEL</strong></p>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>

	</section>


	
	
	
	
	
	
	
	

	
	

	
	

	
	
	
	
	
	
	

	
	

	
	

	
	
	
	
	
	
	

	
	
	
	
	
	
	
	
	

	
	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>