<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row">
			<div class="col-md-10 col-md-offset-1">
				You are logged in as <strong>ADMIN</strong>
				<h2>Airline Users</h2>
				<table class="table table-striped">
					<tr>
						<th>Name</th>
						<th>Email</th>
						<th>Phone</th>
						<th>Website</th>
						<th>Approved</th>
						<th>Created</th>
						<th>Action</th>
					</tr>
					<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></td>
							<td><?php echo e($user->email); ?></td>
							<td><?php echo e($user->phone); ?></td>
							<td><?php echo e($user->website); ?></td>
							<td><?php if($user->approved == 0): ?> No <?php else: ?> Yes <?php endif; ?></td>
							<td><?php echo e($user->created_at); ?></td>
							<td><a href="<?php echo e(route('admin.user.airline', $user->id)); ?>" class="btn btn-primary"><?php if($user->approved == 0): ?> Approve <?php else: ?> Suspend <?php endif; ?></a></td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</table>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>