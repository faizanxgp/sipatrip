<?php $__env->startSection('content'); ?>
	<section class="agent-data">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<div class="home-img">
						<img src="<?php echo e(URL::to('src/images/img1.jpg')); ?>">
					</div>
				</div>
				<div class="col-md-6">
					<div class="home-img2">
						<img src="<?php echo e(URL::to('src/images/img1.jpg')); ?>">
					</div>
					<div class="home-img3">
						<img src="<?php echo e(URL::to('src/images/img1.jpg')); ?>">
					</div>
				</div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>