<?php $__env->startSection('title'); ?>
	Agent
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<section class="login">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="panel1">
						<div class="log-img">
							<img src="images/Sign Up.png">
						</div>
						<div class="join">
							<h4>JOIN US</h4>
						</div>
						<?php if(Session::has('flash_message')): ?>
							<div class="alert alert-success">
								<?php echo e(Session::get('flash_message')); ?>

							</div>
						<?php endif; ?>

					</div>
					<div class="inner-data">
						<div class="top-heading">
							<h2>ACCOUNT PROFILE</h2>
							<i class="fa fa-warning"></i><span>Please enter all details in English. The highlighted fields are required</span>
						</div>
						<h3>Agency Details</h3>
						<form class="agency-form" method="post" action="<?php echo e(route('register')); ?>">
							<div class="row">
								<div class="col-md-2">
									<label><b>First Name <span class="required">*</span></b></label>
								</div>
								<div class="col-md-4  <?php echo e($errors->has('first_name') ? ' has-error' : ''); ?>">
									<input type="text" name="first_name" value="<?php echo e(old('first_name')); ?>" required>
									<?php if($errors->has('first_name')): ?>
										<p class="help-block">
											<strong><?php echo e($errors->first('first_name')); ?></strong>
										</p>
									<?php endif; ?>
								</div>
							</div>
							<div class="row">
								<div class="col-md-2">
									<label><b>Last Name <span class="required">*</span></b></label>
								</div>
								<div class="col-md-4 <?php echo e($errors->has('last_name') ? ' has-error' : ''); ?>">
									<input type="text" name="last_name" value="<?php echo e(old('last_name')); ?>"  required>
									<?php if($errors->has('last_name')): ?>
										<p class="help-block">
											<strong><?php echo e($errors->first('last_name')); ?></strong>
										</p>
									<?php endif; ?>
								</div>
							</div>
							<div class="row">
								<div class="col-md-2">
									<label><b>Email <span class="required">*</span></b></label>
								</div>
								<div class="col-md-4 <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
									<input type="email" name="email" value="<?php echo e(old('email')); ?>"  required>
									<?php if($errors->has('email')): ?>
										<p class="help-block">
											<strong><?php echo e($errors->first('email')); ?></strong>
										</p>
									<?php endif; ?>
								</div>
							</div>
							<div class="row">
								<div class="col-md-2">
									<label><b>Phone no</b></label>
								</div>
								<div class="col-md-4 <?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
									<input type="text" name="phone" value="<?php echo e(old('phone')); ?>" >
									<?php if($errors->has('phone')): ?>
										<p class="help-block">
											<strong><?php echo e($errors->first('phone')); ?></strong>
										</p>
									<?php endif; ?>
								</div>
							</div>
							<div class="row">
								<div class="col-md-2">
									<label><b>Password <span class="required">*</span></b></label>
								</div>
								<div class="col-md-4 <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
									<input type="password" name="password" required>
									<?php if($errors->has('password')): ?>
										<p class="help-block">
											<strong><?php echo e($errors->first('password')); ?></strong>
										</p>
									<?php endif; ?>
								</div>
							</div>
							<div class="row">
								<div class="col-md-2">
									<label><b>Password Confirmation <span class="required">*</span></b></label>
								</div>
								<div class="col-md-4 <?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
									<input type="password" name="password_confirmation" required>
									<?php if($errors->has('password_confirmation')): ?>
										<p class="help-block">
											<strong><?php echo e($errors->first('password_confirmation')); ?></strong>
										</p>
									<?php endif; ?>
								</div>
							</div>
							<div class="row">
								<div class="col-md-2">
									<label><b>Website Link</b></label>
								</div>
								<div class="col-md-4 <?php echo e($errors->has('website') ? ' has-error' : ''); ?>">
									<input type="text" name="website" value="<?php echo e(old('website')); ?>"  >
									<?php if($errors->has('website')): ?>
										<p class="help-block">
											<strong><?php echo e($errors->first('website')); ?></strong>
										</p>
									<?php endif; ?>
								</div>
							</div>
							<div class="row">
								<div class="col-md-1 col-xs-1 <?php echo e($errors->has('agree') ? ' has-error' : ''); ?>">
									<input name="agree" class="checkbox" type="checkbox" checked="">

								</div>
								<div class="col-md-5 col-xs-10">
									<p class="terms"> You must agree to our Terms and Conditions</p>
								</div>
							</div>
							<div class="clearfix">
								<button class="btn btn-danger rb" type="submit" class="cancelbtn">Join Now</button>
								<?php echo e(csrf_field()); ?>

							</div>
							<div class="clearfix1">
								<div class="row">
									<div class="col-md-2">
										<p>Sign Up Using: </p>
									</div>
									<div class="col-md-2">
										<a href="#"><button class="btn btn-danger google-rb"><i class="fa fa-google-plus "></i></button></a>
									</div>
									<div class="col-md-2">
										<a href="#"><button class="btn btn-danger fb-rb"><i class="fa fa-facebook"></i></button></a>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>



    
        
            
                

                
                    
                        

                        
                            

                            
                                

                                
                                    
                                        
                                    
                                
                            
                        

                        
                            

                            
                                

                                
                                    
                                        
                                    
                                
                            
                        

                        
                            

                            
                                

                                
                                    
                                        
                                    
                                
                            
                        

                        
                            

                            
                                
                            
                        

                        
                            
                                
                                    
                                
                            
                        
                    
                
            
        
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>